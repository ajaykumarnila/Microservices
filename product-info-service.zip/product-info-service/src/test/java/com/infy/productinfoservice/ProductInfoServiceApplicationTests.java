package com.infy.productinfoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductInfoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
